// Generated from /Users/vivianchen/Desktop/Milestones1/src/main/java/gen/XPath.g4 by ANTLR 4.13.1
package gen;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link XPathParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface XPathVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link XPathParser#ap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAp(XPathParser.ApContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RpRule2}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRpRule2(XPathParser.RpRule2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code RpRule3}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRpRule3(XPathParser.RpRule3Context ctx);
	/**
	 * Visit a parse tree produced by the {@code RpRule4}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRpRule4(XPathParser.RpRule4Context ctx);
	/**
	 * Visit a parse tree produced by the {@code RpRule5}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRpRule5(XPathParser.RpRule5Context ctx);
	/**
	 * Visit a parse tree produced by the {@code RpRule6}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRpRule6(XPathParser.RpRule6Context ctx);
	/**
	 * Visit a parse tree produced by the {@code OtherRp2}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOtherRp2(XPathParser.OtherRp2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilterRp(XPathParser.FilterRpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BktRp}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBktRp(XPathParser.BktRpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RpRule1}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRpRule1(XPathParser.RpRule1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code OtherRp1}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOtherRp1(XPathParser.OtherRp1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code ComplexFt1}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComplexFt1(XPathParser.ComplexFt1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code ComplexFt2}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComplexFt2(XPathParser.ComplexFt2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code SimpleFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimpleFt(XPathParser.SimpleFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LogicFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicFt(XPathParser.LogicFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BktFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBktFt(XPathParser.BktFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotFt(XPathParser.NotFtContext ctx);
	/**
	 * Visit a parse tree produced by {@link XPathParser#navigationOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNavigationOp(XPathParser.NavigationOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link XPathParser#docName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDocName(XPathParser.DocNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XPathParser#fileName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFileName(XPathParser.FileNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XPathParser#tagName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTagName(XPathParser.TagNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XPathParser#attName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttName(XPathParser.AttNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XPathParser#compOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompOp(XPathParser.CompOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link XPathParser#stringCondition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringCondition(XPathParser.StringConditionContext ctx);
}