package xquery;

import engine.Engine;
import gen.XQueryBaseVisitor;
import gen.XQueryParser;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import engine.evaluator.*;
import xpath.EngineFactory;
import xpath.Xpath;

import java.util.*;

public class QueryFactory extends XQueryBaseVisitor<Query> {

    public QueryFactory(Document doc) throws Exception {
        if (doc == null) {
            throw new NullPointerException("Document is empty");
        }
        this.doc = doc;
        this.queryMap = new HashMap<>();
        this.queryStack = new Stack<>();
        this.xpath = new Xpath();
        this.engineFactory = new EngineFactory();
    }

    @Override public Query visitRelativeQuery(XQueryParser.RelativeQueryContext ctx) {
        return new RelativeQuery(visit(ctx.xq()), Query.opFromString(ctx.navigationOp().getText()), this.engineFactory.visit(xpath.parse(ctx.rp().getText()).rp()));
    }

    @Override public Query visitStrQuery(XQueryParser.StrQueryContext ctx) {
        String str = ctx.STRING().getText();
        return new StrQuery(str.substring(1, str.length()-1));
    }

    @Override public Query visitBktQuery(XQueryParser.BktQueryContext ctx) {
        return new BktQuery(visit(ctx.xq()));
    }

    @Override public Query visitAbsoluteQuery(XQueryParser.AbsoluteQueryContext ctx) {
        List<Node> resultList = null;
        try {
            resultList  = this.xpath.eval(xpath.parse(ctx.ap().getText()));
        } catch (Exception e) {
            resultList = List.of();
            e.printStackTrace();
        }
        return new AbsoluteQuery(resultList);
    }

    @Override public Query visitSimpleQuery(XQueryParser.SimpleQueryContext ctx) {
        return new SimpleQuery(visit(ctx.xq(0)), visit(ctx.xq(1)));
    }

    @Override public Query visitVarQuery(XQueryParser.VarQueryContext ctx) {
        return new VarQuery(this.queryMap.get(ctx.VAR().getText()));
    }

    @Override public Query visitLetXq(XQueryParser.LetXqContext ctx) {
        this.constructClause(ctx.letClause().VAR(), ctx.letClause().xq());
        Query query = visit(ctx.xq());
        this.deconstructClause(ctx.letClause().VAR().size());
        return query;
    }

    @Override public Query visitNegCond(XQueryParser.NegCondContext ctx) {
        return new NotQuery(visit(ctx.cond()));
    }

    @Override public Query visitParaCond(XQueryParser.ParaCondContext ctx) {
        return visit(ctx.cond());
    }

    @Override public Query visitIsCond1(XQueryParser.IsCond1Context ctx) {
        Query q1 = visit(ctx.xq(0));
        Query q2 = visit(ctx.xq(1));
        return new IsQuery(q1, q2);
    }

    @Override public Query visitIsCond2(XQueryParser.IsCond2Context ctx) {
        Query q1 = visit(ctx.xq(0));
        Query q2 = visit(ctx.xq(1));
        return new IsQuery(q1, q2);
    }

    @Override public Query visitStartTag(XQueryParser.StartTagContext ctx) { return visitChildren(ctx); }

    @Override public Query visitEndTag(XQueryParser.EndTagContext ctx) { return visitChildren(ctx); }

    @Override public Query visitAp(XQueryParser.ApContext ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp3(XQueryParser.RpRule3Context ctx) { return visitChildren(ctx); }
    @Override public Query visitBinaryRp1(XQueryParser.OtherRp1Context ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp4(XQueryParser.RpRule4Context ctx) { return visitChildren(ctx); }

    @Override public Query visitParaRp(XQueryParser.BktRpContext ctx) { return visitChildren(ctx); }

    @Override public Query visitBinaryRp2(XQueryParser.OtherRp2Context ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp1(XQueryParser.RpRule1Context ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp2(XQueryParser.RpRule2Context ctx) { return visitChildren(ctx); }

    @Override public Query visitFilterRp(XQueryParser.FilterRpContext ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp5(XQueryParser.RpRule5Context ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp6(XQueryParser.RpRule6Context ctx) { return visitChildren(ctx); }

    @Override public Query visitBinaryFt1(XQueryParser.ComplexFt1Context ctx) { return visitChildren(ctx); }

    @Override public Query visitBinaryFt2(XQueryParser.ComplexFt2Context ctx) { return visitChildren(ctx); }

    @Override public Query visitParaFt(XQueryParser.BktFtContext ctx) { return visitChildren(ctx); }

    @Override public Query visitNegFt(XQueryParser.NotFtContext ctx) { return visitChildren(ctx); }

    @Override public Query visitCompoundFt(XQueryParser.LogicFtContext ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryFt(XQueryParser.SimpleFtContext ctx) { return visitChildren(ctx); }

    @Override public Query visitPathOp(XQueryParser.NavigationOpContext ctx) { return visitChildren(ctx); }

    @Override public Query visitDocName(XQueryParser.DocNameContext ctx) { return visitChildren(ctx); }

    @Override public Query visitFileName(XQueryParser.FileNameContext ctx) { return visitChildren(ctx); }

    @Override public Query visitTagName(XQueryParser.TagNameContext ctx) { return visitChildren(ctx); }

    @Override public Query visitAttName(XQueryParser.AttNameContext ctx) { return visitChildren(ctx); }

    @Override public Query visitCompOp(XQueryParser.CompOpContext ctx) { return visitChildren(ctx); }

    @Override public Query visitStringCondition(XQueryParser.StringConditionContext ctx) { return visitChildren(ctx); }

    private Map<String, List<Node>> queryMap;
    private final Stack<Map<String, List<Node>>> queryStack;
    private final Xpath xpath;
    private final EngineFactory engineFactory;
    private final Document doc;


    private void forXq(int count, List<Node> res, XQueryParser.ForXqContext ctx) throws Exception {
        int size = ctx.forClause().VAR().size();
        if(count == size) {
            if(null != ctx.letClause()) {
                this.constructClause(ctx.letClause().VAR(), ctx.letClause().xq());
            }
            if(null == ctx.whereClause() || (null != ctx.whereClause() && null != visit(ctx.whereClause().cond()).evaluate(this.doc))) {
                res.addAll(visit(ctx.returnClause().xq()).evaluate(this.doc));
            }
            if(null != ctx.letClause()) {
                this.deconstructClause(ctx.letClause().VAR().size());
            }
        } else {
            String var = ctx.forClause().VAR(count).getText();
            List<Node> resNode = visit(ctx.forClause().xq(count)).evaluate(this.doc);
            for(Node node : resNode) {
                Map<String, List<Node>> oldMap = new HashMap<>(this.queryMap);
                this.queryStack.push(oldMap);
                this.queryMap.put(var, List.of(node));
                this.forXq(count+1, res, ctx);
                this.queryMap = this.queryStack.pop();
            }
        }
    }

    @Override public Query visitForXq(XQueryParser.ForXqContext ctx) {
        List<Node> res = new ArrayList<>();
        try {
            this.forXq(0, res, ctx);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // use VarXq as a simple solution
        return new VarQuery(res);
    }

    @Override public Query visitTagXq(XQueryParser.TagXqContext ctx) {
        String tagName = ctx.startTag().tagName().getText();
        Query query = visit(ctx.xq());
        return new TagQuery(tagName, query);
    }

    @Override public Query visitForClause(XQueryParser.ForClauseContext ctx) { return visitChildren(ctx); }

    @Override public Query visitLetClause(XQueryParser.LetClauseContext ctx) { return visitChildren(ctx); }

    @Override public Query visitWhereClause(XQueryParser.WhereClauseContext ctx) { return visitChildren(ctx); }

    @Override public Query visitReturnClause(XQueryParser.ReturnClauseContext ctx) { return visitChildren(ctx); }

    @Override public Query visitEqCond2(XQueryParser.EqCond2Context ctx) {
        Query q1 = visit(ctx.xq(0));
        Query q2 = visit(ctx.xq(1));
        return new EqualQuery(q1, q2);
    }

    @Override public Query visitCompoundCond(XQueryParser.CompoundCondContext ctx) {
        Query c1 = visit(ctx.cond(0));
        Query c2 = visit(ctx.cond(1));
        String logic = ctx.LOGIC().getText();
        return new ComplexQuery(c1, c2, logic);
    }

    @Override public Query visitEqCond1(XQueryParser.EqCond1Context ctx) {
        Query q1 = visit(ctx.xq(0));
        Query q2 = visit(ctx.xq(1));
        return new EqualQuery(q1, q2);
    }

    private void constructClause(List<TerminalNode> varList, List<XQueryParser.XqContext> queryList) {
        if(null == varList || null == queryList || varList.size() != queryList.size()) {
            throw new IllegalArgumentException();
        }

        int count = varList.size();
        for(int i=0; i<count; i++) {
            try {
                List<Node> valueList = visit(queryList.get(i)).evaluate(this.doc);
                String varName = varList.get(i).getText();
                Map<String, List<Node>> oldMap = new HashMap<>(this.queryMap);
                this.queryMap.put(varName, valueList);
                this.queryStack.push(oldMap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void deconstructClause(int count) {
        if(count < 0 || count > this.queryStack.size()) {
            throw new IllegalArgumentException();
        }
        for(int i=0; i<count; i++) {
            this.queryMap = this.queryStack.pop();
        }
    }

    @Override public Query visitSatCond(XQueryParser.SatCondContext ctx) {
        this.constructClause(ctx.satisfy().VAR(), ctx.satisfy().xq());

        Query finalCond = visit(ctx.cond());
        Query condQuery = null;
        try {
            condQuery = new SatQuery(finalCond.evaluate(this.doc));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.deconstructClause(ctx.satisfy().VAR().size());
        }

        return condQuery;
    }

    @Override public Query visitEmptyCond(XQueryParser.EmptyCondContext ctx) {
        Query query = visit(ctx.xq());
        return new EmptyQuery(query);
    }

}
