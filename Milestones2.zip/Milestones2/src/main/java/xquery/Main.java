package xquery;

import gen.XQueryParser;
import gen.XQueryLexer;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import xpath.Xpath;
import org.w3c.dom.Attr;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;


import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.PrintStream;

public class Main {
    public static void main(String[] args) throws IOException {
        String input_path = args[0];
        // String input_path = "/Users/vivianchen/Desktop/Milestones1/src/main/java/input/queryTest1.txt";
        try {
            final XQueryLexer lexer = new XQueryLexer(CharStreams.fromFileName(input_path));
            final CommonTokenStream token = new CommonTokenStream(lexer);
            final XQueryParser parser = new XQueryParser(token);
            Xquery xq = new Xquery();
            List<Node> res = xq.eval(parser);
            convert(res);
        }   catch (Exception e) {
            System.err.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    public static void convert(List<Node> res) throws Exception{
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

        FileOutputStream fileOutputStream = new FileOutputStream(new File("output.xml"));
        PrintStream printStream = new PrintStream(fileOutputStream);
        StreamResult streamResult = new StreamResult(printStream);

        // printStream.print("<result>\n");
        for (Node n : res) {
            if (n instanceof Attr || n instanceof Text) {
                System.out.println(n.getTextContent());
            } else {
                transformer.transform(new DOMSource(n), streamResult);
            }
        }
        // printStream.print("\n</result>");

        printStream.close();
        fileOutputStream.close();
    }

}
