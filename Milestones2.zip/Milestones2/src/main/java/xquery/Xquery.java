package xquery;

import gen.XQueryParser;
import org.antlr.v4.runtime.ParserRuleContext;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import engine.evaluator.Query;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.util.List;

public class Xquery {

    public List<Node> eval(XQueryParser parser) throws Exception {
        final Document doc;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = dbf.newDocumentBuilder();
        doc = documentBuilder.newDocument();
        final ParserRuleContext tree = parser.xq();
        QueryFactory queryFactory = new QueryFactory(doc);
        final Query root = queryFactory.visit(tree);
        return root.evaluate(doc);
    }

}
