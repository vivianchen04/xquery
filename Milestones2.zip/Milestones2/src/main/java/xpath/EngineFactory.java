package xpath;

import engine.*;
import gen.XPathBaseVisitor;
import gen.XPathParser;

import static engine.ComplexFt.compFromString;
import static engine.LogicFt.logicFromString;


public class EngineFactory extends XPathBaseVisitor<Engine> {

    @Override
    public Engine visitAp(XPathParser.ApContext ctx) {
        String document = ctx.docName().fileName().getText();
        Engine.navigationOp operation = Engine.opFromString(ctx.navigationOp().getText());
        Engine relativePath = visit(ctx.rp());
        return new AbsolutePath(document.substring(1, document.length()-1), operation, relativePath);
    }

    @Override
    public Engine visitOtherRp1(XPathParser.OtherRp1Context ctx) {
        OtherRp.Op operation = OtherRp.opFromString(ctx.navigationOp().getText());
        return new OtherRp(visit(ctx.rp(0)), visit(ctx.rp(1)), operation);
    }

    @Override
    public Engine visitOtherRp2(XPathParser.OtherRp2Context ctx) {
        OtherRp.Op operation = OtherRp.opFromString(ctx.COMMA().getText());
        return new OtherRp(visit(ctx.rp(0)), visit(ctx.rp(1)), operation);
    }

    @Override
    public Engine visitRpRule3(XPathParser.RpRule3Context ctx) {
        return new RpRule(RpRule.Type.Text, "text()");
    }

    @Override
    public Engine visitRpRule4(XPathParser.RpRule4Context ctx) {
        return new RpRule(RpRule.Type.Star, "*");
    }

    @Override
    public Engine visitBktRp(XPathParser.BktRpContext ctx) {
        Engine relativePath = visit(ctx.rp());
        return new BktRp(relativePath);
    }

    @Override
    public Engine visitRpRule1(XPathParser.RpRule1Context ctx) {
        return new RpRule(RpRule.Type.Tag, ctx.tagName().getText());
    }

    @Override
    public Engine visitRpRule2(XPathParser.RpRule2Context ctx) {
        return new RpRule(RpRule.Type.Att, ctx.attName().ID().getText());
    }

    @Override
    public Engine visitFilterRp(XPathParser.FilterRpContext ctx) {
        return new FilterRp(visit(ctx.rp()), visit(ctx.filter()));
    }

    @Override
    public Engine visitRpRule5(XPathParser.RpRule5Context ctx) {
        return new RpRule(RpRule.Type.Self, ".");
    }

    @Override
    public Engine visitRpRule6(XPathParser.RpRule6Context ctx) {
        return new RpRule(RpRule.Type.PREV, "..");
    }

    @Override
    public Engine visitComplexFt1(XPathParser.ComplexFt1Context ctx) {
        ComplexFt.Comparator complex = compFromString(ctx.compOp().getText());
        return new ComplexFt(visit(ctx.rp(0)), visit(ctx.rp(1)), complex);
    }

    @Override
    public Engine visitComplexFt2(XPathParser.ComplexFt2Context ctx) {
        String stringConstant = ctx.stringCondition().STRING().getText();
        return new BinaryConstantFt(visit(ctx.rp()), stringConstant.substring(1, stringConstant.length()-1));
    }

    @Override
    public Engine visitBktFt(XPathParser.BktFtContext ctx) {
        return new BktFt(visit(ctx.filter())); //filter
    }

    @Override
    public Engine visitNotFt(XPathParser.NotFtContext ctx) {
        return new NotFt(visit(ctx.filter()));
    }

    @Override
    public Engine visitLogicFt(XPathParser.LogicFtContext ctx) {
        LogicFt.LOGIC logic = logicFromString(ctx.LOGIC().getText());
        return new LogicFt(visit(ctx.filter(0)), visit(ctx.filter(1)), logic);
    }

    @Override
    public Engine visitSimpleFt(XPathParser.SimpleFtContext ctx) {
        return new SimpleFt(visit(ctx.rp()));
    }
}