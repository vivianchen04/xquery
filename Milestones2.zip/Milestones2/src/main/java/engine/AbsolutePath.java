package engine;

import org.w3c.dom.Node;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AbsolutePath implements Engine {
    public String findDocName() {
        return doc;
    }
    public AbsolutePath(String document, Engine.navigationOp navigationOp, Engine rp) {
        if (document == null) {
            throw new NullPointerException("Document is empty");
        }
        if (navigationOp == null) {
            throw new NullPointerException("Slash is empty");
        }
        if (rp == null) {
            throw new NullPointerException("Relative Path is empty");
        }
        this.doc = document;
        this.navigationOp = navigationOp;
        this.rp = rp;
    }

    @Override
    public boolean equals(Object object) {
        if(object == this) {
            return true;
        }
        if(null == object || this.getClass() != object.getClass()) {
            return false;
        }
        AbsolutePath path = (AbsolutePath) object;
        return Objects.equals(this.doc, path.doc) && Objects.equals(this.navigationOp, path.navigationOp) && Objects.equals(this.rp, path.rp);
    }

    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception{
        if (navigationOp == Engine.navigationOp.CP) {
            return rp.eval(inputNodes);
        } else {
            List<Node> rpInput = new ArrayList<>();
            Engine.getSubNodes(inputNodes, rpInput);
            return rp.eval(rpInput);
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.doc, this.navigationOp, this.rp);
    }
    @Override
    public EngineType getEngineType() {
        return EngineType.AP;
    }
    @Override
    public String toString() {
        return this.doc + this.navigationOp + this.rp;
    }
    final private String doc;
    final private navigationOp navigationOp;
    final private Engine rp;
}
