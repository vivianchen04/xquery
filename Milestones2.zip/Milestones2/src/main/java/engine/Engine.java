package engine;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

public interface Engine {

    default List<Node> filter(Engine rp, Node nodes) throws Exception {
        if (rp == null) {
            throw new NullPointerException("Engine rp must not be null");
        }
        if (nodes == null) {
            throw new NullPointerException("Node nodes must not be null");
        }
        return rp.eval(List.of(nodes));
    }

    static void getSubNodes(List<Node> nodes, List<Node> res) {
        for (Node n : nodes) {
            res.add(n);
            NodeList subNodes = n.getChildNodes();
            List<Node> subList = new ArrayList<>();
            for (int i = 0; i < subNodes.getLength(); i++) {
                subList.add(subNodes.item(i));
            }
            getSubNodes(subList, res);
        }
    }

    static navigationOp opFromString(String s) {
        return switch (s) {
            case "/" -> navigationOp.CP;
            case "//" -> navigationOp.PP;
            default -> null;
        };
    }

    enum EngineType {
        AP,
        RpRule,
        OtherRp,
        BktRp,
        FilterRp,
        SimpleFt,
        ComplexFt,
        BktFt,
        LogicFt,
        NotFt
    }

    List<Node> eval(List<Node> nodes) throws Exception;

    EngineType getEngineType();

    enum navigationOp {
        CP, PP //current path, prev path
    }
}


