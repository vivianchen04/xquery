package engine.evaluator;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.List;
import java.util.Objects;

public class BktQuery implements Query {

    private final Query query;

    public BktQuery(Query query) {
        Objects.requireNonNull(query, "Query is NULL!");
        this.query = query;
    }

    @Override
    public List<Node> evaluate(Document doc) throws Exception {
        return this.query.evaluate(doc);
    }

    @Override
    public QueryType getQueryType() {
        return QueryType.BktQuery;
    }
}
