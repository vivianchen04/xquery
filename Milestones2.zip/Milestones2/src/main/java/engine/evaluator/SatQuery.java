package engine.evaluator;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.List;

public class SatQuery implements Query {

    private final boolean condRes;

    public SatQuery(List<Node> condRes) {
        this.condRes = (condRes != null);
    }

    @Override
    public List<Node> evaluate(Document doc) throws Exception {
        return this.condRes ? List.of():null;
    }

    @Override
    public QueryType getQueryType() {
        return QueryType.SatCond;
    }
}
