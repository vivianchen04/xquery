package engine.evaluator;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.List;

public class IsQuery implements Query {

    private final Query query1;
    private final Query query2;

    public IsQuery(Query query1, Query query2) {
        if (query1 == null) {
            throw new NullPointerException("Query 1 is NULL!");
        }
        if (query2 == null) {
            throw new NullPointerException("Query 2 is NULL!");
        }
        this.query1 = query1;
        this.query2 = query2;
    }

    @Override
    // if returned list is NULL, then the condition is false
    // Or it is true
    public List<Node> evaluate(Document doc) throws Exception {
        List<Node> resLeft = this.query1.evaluate(doc);
        List<Node> resRight = this.query2.evaluate(doc);
        for(Node n : resLeft) {
            for(Node m : resRight) {
                if(n.isSameNode(m)) {
                    return List.of();
                }
            }
        }
        return null;
    }

    @Override
    public QueryType getQueryType() {
        return QueryType.IsCond;
    }
}

