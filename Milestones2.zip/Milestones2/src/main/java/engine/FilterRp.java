package engine;

import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class FilterRp implements Engine {

    final private Engine rp;
    final private Engine ft;

    public FilterRp(Engine rp, Engine ft) {
        if (rp == null) {
            throw new NullPointerException("rp type must not be null");
        }
        if (ft == null) {
            throw new NullPointerException("ft type must not be null");
        }


        this.rp = rp;
        this.ft = ft;
    }

    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception {
        List<Node> interResult = this.rp.eval(inputNodes);
        return this.ft.eval(interResult);
    }

    @Override
    public EngineType getEngineType() {
        return EngineType.FilterRp;
    }
}

