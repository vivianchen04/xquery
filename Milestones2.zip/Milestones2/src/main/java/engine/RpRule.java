package engine;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RpRule implements Engine{
    public RpRule(Type type, String cur) {
        if (type == null) {
            throw new NullPointerException("rp type must not be null");
        }
        if (cur == null) {
            throw new NullPointerException("cur must not be null");
        }
        this.type = type;
        this.cur = cur;
    }

    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception{
        List<Node> res = new ArrayList<>();
        for(Node n: inputNodes) {
            if(type == Type.Self) {
                res.add(n);
            } else if (type == Type.PREV) {
                if(n instanceof Document) {
                    continue;
                }
                res.add(n.getParentNode());
            } else if (type == Type.Att) {
                res.add(n.getAttributes().getNamedItem(this.cur));
            } else {
                NodeList childNodes = n.getChildNodes();
                for (int i = 0; i < childNodes.getLength(); i++) {
                    Node childNode = childNodes.item(i);
                    switch (type) {
                        case Tag:
                            if (childNode.getNodeType() == Node.ELEMENT_NODE && childNode.getNodeName().equals(cur)) {
                                res.add(childNode);
                            }
                            break;
                        case Text:
                            if (childNode.getNodeType() == Node.TEXT_NODE) {
                                res.add(childNode);
                            }
                            break;
                        case Star:
                            res.add(childNode);
                            break;
                        default:
                            throw new Exception("Error: " + this);
                    }
                }
            }
        }
        return res;
    }

    @Override
    public EngineType getEngineType() {
        return EngineType.RpRule;
    }

    public enum Type {
        Tag, Att, Text, Star, Self, PREV
    }

    final private Type type;
    final private String cur;

    @Override
    public String toString() {
        return "RpRule{" +
                "type=" + type +
                ", cur='" + cur + '\'' +
                '}';
    }
}
