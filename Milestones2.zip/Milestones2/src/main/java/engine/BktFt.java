package engine;


import org.w3c.dom.Node;

import java.util.List;
import java.util.Objects;

public class BktFt implements Engine{
    public BktFt(Engine engine) {
        if (engine == null) {
            throw new NullPointerException("ft must not be null");
        }
        this.engine = engine;
    }

    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception {
        return this.engine.eval(inputNodes);
    }

    @Override
    public EngineType getEngineType() {
        return EngineType.BktFt;
    }

    final private Engine engine;

}
