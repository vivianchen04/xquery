package engine;
import org.w3c.dom.Node;

import java.util.List;
import java.util.Objects;

public class BktRp implements Engine{
    public BktRp(Engine rp) {
        if (rp == null) {
            throw new NullPointerException("rp type must not be null");
        }
        this.rp = rp;
    }
    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception {
        return this.rp.eval(inputNodes);
    }
    @Override
    public EngineType getEngineType() {
        return EngineType.BktRp;
    }
    final private Engine rp;
}
