package engine.evaluator;

import engine.Engine;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

public class RelativeQuery implements Query {

    private final Query query;
    private final navigationOp op;
    private final Engine rp;

    public RelativeQuery(Query query, navigationOp op, Engine rp) {
        Objects.requireNonNull(query, "Query is NULL!");
        Objects.requireNonNull(op, "Op is NULL!");
        Objects.requireNonNull(rp, "Relative path is NULL!");
        this.query = query;
        this.op = op;
        this.rp = rp;
    }

    @Override
    public List<Node> evaluate(Document doc) throws Exception {
        List<Node> res = this.query.evaluate(doc);
        switch (this.op) {
            case CP:
                return new ArrayList<>(new HashSet<>(this.rp.eval(res)));
            case PP:
                List<Node> descendingList = new ArrayList<>();
                getAllDescentNodes(res, descendingList);
                return new ArrayList<>(new HashSet<>(this.rp.eval(descendingList)));
            default:
                throw new Exception("Evaluation error in " + this);
        }
    }

    @Override
    public QueryType getQueryType() {
        return QueryType.RelativeQuery;
    }
}
