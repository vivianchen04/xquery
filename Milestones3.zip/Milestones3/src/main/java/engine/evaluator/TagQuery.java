package engine.evaluator;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class TagQuery implements Query {

    private final String tagName;
    private final Query query;

    public TagQuery(String tagName, Query query) {
        Objects.requireNonNull(tagName, "Tag name is NULL!");
        Objects.requireNonNull(query, "Query is NULL!");
        this.tagName = tagName;
        this.query = query;
    }

    @Override
    public List<Node> evaluate(Document doc) throws Exception {
        List<Node> res = this.query.evaluate(doc);
        Node node = makeElement(doc, this.tagName, res);
        return new ArrayList<>(Arrays.asList(node));
    }

    @Override
    public QueryType getQueryType() {
        return QueryType.TagXq;
    }
}
