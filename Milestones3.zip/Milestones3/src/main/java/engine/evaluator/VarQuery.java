package engine.evaluator;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.List;
import java.util.Objects;

public class VarQuery implements Query {

    private final List<Node> res;

    public VarQuery(List<Node> nodeList) {
        Objects.requireNonNull(nodeList, "Node list is NULL");
        this.res = nodeList;
    }

    @Override
    public List<Node> evaluate(Document doc) throws Exception {
        return this.res;
    }

    @Override
    public QueryType getQueryType() {
        return QueryType.VarQuery;
    }
}
