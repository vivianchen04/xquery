package engine;
import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Node;

public class BinaryConstantFt implements Engine {
    public BinaryConstantFt(Engine leftRp, String constant) {
        if (leftRp == null) {
            throw new NullPointerException("rp type must not be null");
        }
        if (constant == null) {
            throw new NullPointerException("rp type must not be null");
        }

        this.leftRp = leftRp;
        this.constant = constant;
    }

    @Override
    public List<Node> eval(List<Node> nodes) throws Exception {
        List<Node> resultList = new ArrayList<>();
        for(Node n : nodes) {
            for(Node m : this.filter(this.leftRp, n)) {
                if(this.constant.equals(m.getNodeValue())) {
                    resultList.add(n);
                    break;
                }
            }
        }
        return resultList;
    }

    final private Engine leftRp;
    final private String constant;

    @Override
    public EngineType getEngineType() {
        return EngineType.ComplexFt;
    }
}
