package engine;

import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class NotFt implements Engine{

    final private Engine ft;

    public NotFt(Engine ft) {
        if (ft == null) {
            throw new NullPointerException("ft type must not be null");
        }

        this.ft = ft;
    }

    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception {
        List<Node> interList = this.ft.eval(inputNodes);
        List<Node> resList = new ArrayList<>(inputNodes);
        for(Node n : interList) {
            resList.remove(n);
        }
        return resList;
    }

    @Override
    public EngineType getEngineType() {
        return EngineType.NotFt;
    }
}
