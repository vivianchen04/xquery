package engine;

import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

public class OtherRp implements Engine {
    public OtherRp(Engine leftRp, Engine rightRp, Op op) {
        if (leftRp == null) {
            throw new NullPointerException("leftrp type must not be null");
        }
        if (rightRp == null) {
            throw new NullPointerException("rightrp type must not be null");
        }
        if (op == null) {
            throw new NullPointerException("op type must not be null");
        }

        this.leftRp = leftRp;
        this.rightRp = rightRp;
        this.op = op;
    }

    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception {
        List<Node> leftResult = leftRp.eval(inputNodes);
        switch (op) {
            case SL:
                return new ArrayList<>(new HashSet<>(rightRp.eval(leftResult)));
            case DSL:
                List<Node> rightInput = new ArrayList<>();
                Engine.getSubNodes(leftResult, rightInput);
                return new ArrayList<>(new HashSet<>(rightRp.eval(rightInput)));
            case COMMA:
                boolean success = leftResult.addAll(rightRp.eval(inputNodes));
                if(success) {
                    return leftResult;
                }
                return null;
            default:
                throw new Exception("Evaluation error in " + this);
        }
    }

    @Override
    public EngineType getEngineType() {
        return EngineType.OtherRp;
    }

    public static Op opFromString(String s) {
        return switch (s) {
            case "/" -> Op.SL;
            case "//" -> Op.DSL;
            case "," -> Op.COMMA;
            default -> null;
        };
    }

    public enum Op {
        SL, DSL, COMMA
    }

    final private Engine leftRp;
    final private Engine rightRp;
    final private Op op;
}
