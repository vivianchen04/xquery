package engine;

import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class LogicFt implements Engine{

    final private Engine ft1;
    final private Engine ft2;
    final private LOGIC logic;

    public LogicFt(Engine ft1, Engine ft2, LOGIC logic) {
        Objects.requireNonNull(ft1, "Filter 1 is null!");
        Objects.requireNonNull(ft2, "filter 2 is NULL!");
        Objects.requireNonNull(logic, "Conjunction is NULL!");

        this.ft1 = ft1;
        this.ft2 = ft2;
        this.logic = logic;
    }

    public enum LOGIC {
        AND, OR;
    }

    public static LOGIC logicFromString(String s) {
        return switch (s) {
            case "and" -> LOGIC.AND;
            case "or" -> LOGIC.OR;
            default -> null;
        };
    }

    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception {
        switch (this.logic) {
            case AND -> {
                List<Node> leftResult = this.ft1.eval(inputNodes);  // subset of original inputNodes
                return this.ft2.eval(leftResult);
            }
            case OR -> {
                List<Node> resultList = new ArrayList<>();
                for (Node n : inputNodes) {
                    if (!this.ft1.eval(List.of(n)).isEmpty() || !this.ft2.eval(List.of(n)).isEmpty()) {
                        resultList.add(n);
                    }
                }
                return resultList;
            }
            default -> throw new Exception("Not supported conjunction: " + this.logic);
        }
    }

    @Override
    public EngineType getEngineType() {
        return EngineType.LogicFt;
    }
}
