package engine;


import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SimpleFt implements Engine{
    public SimpleFt(Engine rp) {
        if (rp == null) {
            throw new NullPointerException("rp must not be null");
        }
        this.rp = rp;
    }

    @Override
    public List<Node> eval(List<Node> inputNodes) throws Exception {
        List<Node> res = new ArrayList<>();
        for(Node n : inputNodes) {
            if(!this.filter(this.rp, n).isEmpty()) {
                res.add(n);
            }
        }
        return res;
    }

    @Override
    public EngineType getEngineType() {
        return EngineType.SimpleFt;
    }
    final private Engine rp;
}
