package xpath;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.util.ArrayList;

import gen.XPathLexer;
import gen.XPathParser;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import java.util.List;

import engine.AbsolutePath;
import engine.Engine;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import org.antlr.v4.runtime.ParserRuleContext;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Xpath {

    public XPathParser parse(String path)  {
        final XPathLexer lexer = new XPathLexer(CharStreams.fromString(path));
        final CommonTokenStream tokens = new CommonTokenStream(lexer);
        return new XPathParser(tokens);
    }

    public List<Node> eval(XPathParser parser) throws Exception {

        final DocumentBuilder documentBuilder;
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        documentBuilder = documentBuilderFactory.newDocumentBuilder();
        documentBuilder.setEntityResolver(new MyResolver());

        final ParserRuleContext tree = parser.ap();
        final EngineFactory engineFactory = new EngineFactory();
        final Engine rootEng = engineFactory.visit(tree);

        AbsolutePath apEng = (AbsolutePath)rootEng;
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        InputStream inputStream = classloader.getResourceAsStream(apEng.findDocName());

        Document doc = documentBuilder.parse(inputStream);

        List<Node> inputNodes = new ArrayList<>();
        inputNodes.add(doc);

        return apEng.eval(inputNodes);
    }
    public class MyResolver implements EntityResolver {

        public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
            if (systemId.contains("play.dtd")) {
                ClassLoader classloader = Thread.currentThread().getContextClassLoader();
                InputStream myDtdRes = classloader.getResourceAsStream("play.dtd");
                return new InputSource(myDtdRes);
            } else {
                return null;
            }
        }
    }


}
