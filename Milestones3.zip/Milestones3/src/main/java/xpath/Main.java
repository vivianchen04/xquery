package xpath;
import gen.XPathLexer;
import gen.XPathParser;
import org.antlr.v4.runtime.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.w3c.dom.Attr;
import org.w3c.dom.Node;
import org.w3c.dom.Text;


import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.PrintStream;
import java.util.List;

public class Main{
    public static void main(String[] args) throws IOException {
        // String input_path = args[0];
        String input_path = "/Users/vivianchen/Desktop/Milestones1/src/main/java/input/test4.txt";

        try {
            final XPathLexer lexer = new XPathLexer(CharStreams.fromFileName(input_path));
            final CommonTokenStream token = new CommonTokenStream(lexer);
            final XPathParser parser = new XPathParser(token);
            Xpath xp = new Xpath();
            List<Node> res = xp.eval(parser);
            convert(res);
        }   catch (Exception e) {
            System.err.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    public static void convert(List<Node> res) throws Exception {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

        FileOutputStream fileOutputStream = new FileOutputStream(new File("output.xml"));
        PrintStream printStream = new PrintStream(fileOutputStream);
        StreamResult streamResult = new StreamResult(printStream);

        printStream.print("<result>\n");
        for (Node n : res) {
            if (n instanceof Attr || n instanceof Text) {
                System.out.println(n.getTextContent());
            } else {
                transformer.transform(new DOMSource(n), streamResult);
            }
        }
        printStream.print("\n</result>");

        printStream.close();
        fileOutputStream.close();
    }


}
