package xquery;

import gen.XQueryLexer;
import gen.XQueryParser;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.ParserRuleContext;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import engine.evaluator.Query;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.util.List;

public class Xquery {
    private CommonTokenStream createTokenStream(String input) {
        XQueryLexer lexer = new XQueryLexer(CharStreams.fromString(input));
        return new CommonTokenStream(lexer);
    }

    public XQueryParser parse(String path)  {
        CommonTokenStream tokens = createTokenStream(path);
        return new XQueryParser(tokens);
    }

    public List<Node> eval(String path) throws Exception {
        final XQueryLexer lexer = new XQueryLexer(CharStreams.fromString(path));
        final CommonTokenStream tokens = new CommonTokenStream(lexer);
        final XQueryParser parser = new XQueryParser(tokens);
        final Document doc;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = dbf.newDocumentBuilder();
        doc = documentBuilder.newDocument();
        final ParserRuleContext tree = parser.xq();
        QueryFactory queryFactory = new QueryFactory(doc);
        final Query root = queryFactory.visit(tree);
        return root.evaluate(doc);
    }

}
