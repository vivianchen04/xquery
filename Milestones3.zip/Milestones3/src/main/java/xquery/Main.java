package xquery;

import engine.evaluator.ReWriter;
import gen.XQueryLexer;
import gen.XQueryParser;
import org.apache.commons.cli.*;
import org.w3c.dom.Node;

import java.io.*;
import java.util.List;

import org.w3c.dom.Text;
import org.w3c.dom.Attr;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;


import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.PrintStream;

public class Main {
    public static void main(String[] args) {
        try {
            CommandLine commandLine = setupCommandLine(args);
            if (commandLine.hasOption("r")) {
                processRewriteOption(commandLine);
            } else {
                processQueryOption(commandLine);
            }
        } catch (Exception e) {
            System.err.println("Error for command line: " + e.getMessage());
            e.printStackTrace();
            System.exit(2);
        }
    }

    private static CommandLine setupCommandLine(String[] args) throws ParseException {
        Option optionR = Option.builder("r")
                .hasArg(false)
                .required(false)
                .desc("activate the rewriter")
                .longOpt("rewrite")
                .build();
        Option optionP = Option.builder("p")
                .hasArg(true)
                .required(true)
                .desc("specifies the input query file")
                .longOpt("file path")
                .build();

        Options options = new Options();
        options.addOption(optionR);
        options.addOption(optionP);

        CommandLineParser parser = new DefaultParser();
        return parser.parse(options, args);
    }

    private static void processRewriteOption(CommandLine commandLine) throws IOException {
        String inputPath = commandLine.getOptionValue("p");
        String query = readFileContents(inputPath);
        Xquery xq = new Xquery();
        String rewritten = ReWriter.convert((XQueryParser.ForXqContext) xq.parse(query).xq());
        writeFileContents("./rewrite.txt", rewritten);
    }

    private static void processQueryOption(CommandLine commandLine) {
        try {
            String inputPath = commandLine.getOptionValue("p");
            String query = readFileContents(inputPath);
            Xquery xq = new Xquery();
            long t1 = System.currentTimeMillis();
            List<Node> result = xq.eval(query);
            long t2 = System.currentTimeMillis();
            System.out.printf("Runtime: %d ms\n", t2 - t1);
            convert(result);
        } catch (Exception e) {
            System.err.println("Failed to process query: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void writeFileContents(String filePath, String content) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            file.createNewFile();
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
            bw.write(content);
        }
    }

    public static void convert(List<Node> res) throws Exception{
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

        FileOutputStream fileOutputStream = new FileOutputStream(new File("output.xml"));
        PrintStream printStream = new PrintStream(fileOutputStream);
        StreamResult streamResult = new StreamResult(printStream);

        printStream.print("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
        printStream.print("<RESULT>\n");
        for (Node n : res) {
            if (n instanceof Attr || n instanceof Text) {
                System.out.println(n.getTextContent());
            } else {
                transformer.transform(new DOMSource(n), streamResult);
            }
        }
        printStream.print("</RESULT>");

        printStream.close();
        fileOutputStream.close();
    }

    private static String readFileContents(String filePath) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String strLine;
            while ((strLine = br.readLine()) != null) {
                contentBuilder.append(strLine);
                contentBuilder.append(" ");
            }
        }
        return contentBuilder.toString().trim();
    }

}
