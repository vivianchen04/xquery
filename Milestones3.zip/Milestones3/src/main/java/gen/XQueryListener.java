// Generated from /Users/vivianchen/Desktop/Milestones3/src/main/java/gen/XQuery.g4 by ANTLR 4.13.1
package gen;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link XQueryParser}.
 */
public interface XQueryListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by the {@code SimpleQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterSimpleQuery(XQueryParser.SimpleQueryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SimpleQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitSimpleQuery(XQueryParser.SimpleQueryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code VarQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterVarQuery(XQueryParser.VarQueryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code VarQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitVarQuery(XQueryParser.VarQueryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code JoinXq}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterJoinXq(XQueryParser.JoinXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code JoinXq}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitJoinXq(XQueryParser.JoinXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AbsoluteQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterAbsoluteQuery(XQueryParser.AbsoluteQueryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AbsoluteQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitAbsoluteQuery(XQueryParser.AbsoluteQueryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LetXq}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterLetXq(XQueryParser.LetXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LetXq}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitLetXq(XQueryParser.LetXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BktQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterBktQuery(XQueryParser.BktQueryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BktQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitBktQuery(XQueryParser.BktQueryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ForXq}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterForXq(XQueryParser.ForXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ForXq}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitForXq(XQueryParser.ForXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RelativeQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterRelativeQuery(XQueryParser.RelativeQueryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RelativeQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitRelativeQuery(XQueryParser.RelativeQueryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StrQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterStrQuery(XQueryParser.StrQueryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StrQuery}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitStrQuery(XQueryParser.StrQueryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code TagXq}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterTagXq(XQueryParser.TagXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code TagXq}
	 * labeled alternative in {@link XQueryParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitTagXq(XQueryParser.TagXqContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#constantList}.
	 * @param ctx the parse tree
	 */
	void enterConstantList(XQueryParser.ConstantListContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#constantList}.
	 * @param ctx the parse tree
	 */
	void exitConstantList(XQueryParser.ConstantListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Join1}
	 * labeled alternative in {@link XQueryParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void enterJoin1(XQueryParser.Join1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code Join1}
	 * labeled alternative in {@link XQueryParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void exitJoin1(XQueryParser.Join1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code Join2}
	 * labeled alternative in {@link XQueryParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void enterJoin2(XQueryParser.Join2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code Join2}
	 * labeled alternative in {@link XQueryParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void exitJoin2(XQueryParser.Join2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code Join3}
	 * labeled alternative in {@link XQueryParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void enterJoin3(XQueryParser.Join3Context ctx);
	/**
	 * Exit a parse tree produced by the {@code Join3}
	 * labeled alternative in {@link XQueryParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void exitJoin3(XQueryParser.Join3Context ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#forClause}.
	 * @param ctx the parse tree
	 */
	void enterForClause(XQueryParser.ForClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#forClause}.
	 * @param ctx the parse tree
	 */
	void exitForClause(XQueryParser.ForClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#letClause}.
	 * @param ctx the parse tree
	 */
	void enterLetClause(XQueryParser.LetClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#letClause}.
	 * @param ctx the parse tree
	 */
	void exitLetClause(XQueryParser.LetClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#whereClause}.
	 * @param ctx the parse tree
	 */
	void enterWhereClause(XQueryParser.WhereClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#whereClause}.
	 * @param ctx the parse tree
	 */
	void exitWhereClause(XQueryParser.WhereClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#returnClause}.
	 * @param ctx the parse tree
	 */
	void enterReturnClause(XQueryParser.ReturnClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#returnClause}.
	 * @param ctx the parse tree
	 */
	void exitReturnClause(XQueryParser.ReturnClauseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EqCond2}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterEqCond2(XQueryParser.EqCond2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code EqCond2}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitEqCond2(XQueryParser.EqCond2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code CompoundCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterCompoundCond(XQueryParser.CompoundCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CompoundCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitCompoundCond(XQueryParser.CompoundCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EqCond1}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterEqCond1(XQueryParser.EqCond1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code EqCond1}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitEqCond1(XQueryParser.EqCond1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code SatCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterSatCond(XQueryParser.SatCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SatCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitSatCond(XQueryParser.SatCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EmptyCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterEmptyCond(XQueryParser.EmptyCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EmptyCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitEmptyCond(XQueryParser.EmptyCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NegCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterNegCond(XQueryParser.NegCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NegCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitNegCond(XQueryParser.NegCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ParaCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterParaCond(XQueryParser.ParaCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParaCond}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitParaCond(XQueryParser.ParaCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IsCond1}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterIsCond1(XQueryParser.IsCond1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code IsCond1}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitIsCond1(XQueryParser.IsCond1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code IsCond2}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterIsCond2(XQueryParser.IsCond2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code IsCond2}
	 * labeled alternative in {@link XQueryParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitIsCond2(XQueryParser.IsCond2Context ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#satisfy}.
	 * @param ctx the parse tree
	 */
	void enterSatisfy(XQueryParser.SatisfyContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#satisfy}.
	 * @param ctx the parse tree
	 */
	void exitSatisfy(XQueryParser.SatisfyContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#startTag}.
	 * @param ctx the parse tree
	 */
	void enterStartTag(XQueryParser.StartTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#startTag}.
	 * @param ctx the parse tree
	 */
	void exitStartTag(XQueryParser.StartTagContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#endTag}.
	 * @param ctx the parse tree
	 */
	void enterEndTag(XQueryParser.EndTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#endTag}.
	 * @param ctx the parse tree
	 */
	void exitEndTag(XQueryParser.EndTagContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#ap}.
	 * @param ctx the parse tree
	 */
	void enterAp(XQueryParser.ApContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#ap}.
	 * @param ctx the parse tree
	 */
	void exitAp(XQueryParser.ApContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule2}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule2(XQueryParser.RpRule2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule2}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule2(XQueryParser.RpRule2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule3}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule3(XQueryParser.RpRule3Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule3}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule3(XQueryParser.RpRule3Context ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule4}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule4(XQueryParser.RpRule4Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule4}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule4(XQueryParser.RpRule4Context ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule5}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule5(XQueryParser.RpRule5Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule5}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule5(XQueryParser.RpRule5Context ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule6}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule6(XQueryParser.RpRule6Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule6}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule6(XQueryParser.RpRule6Context ctx);
	/**
	 * Enter a parse tree produced by the {@code OtherRp2}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterOtherRp2(XQueryParser.OtherRp2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code OtherRp2}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitOtherRp2(XQueryParser.OtherRp2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterFilterRp(XQueryParser.FilterRpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitFilterRp(XQueryParser.FilterRpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BktRp}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterBktRp(XQueryParser.BktRpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BktRp}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitBktRp(XQueryParser.BktRpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule1}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule1(XQueryParser.RpRule1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule1}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule1(XQueryParser.RpRule1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code OtherRp1}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterOtherRp1(XQueryParser.OtherRp1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code OtherRp1}
	 * labeled alternative in {@link XQueryParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitOtherRp1(XQueryParser.OtherRp1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code ComplexFt1}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterComplexFt1(XQueryParser.ComplexFt1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code ComplexFt1}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitComplexFt1(XQueryParser.ComplexFt1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code ComplexFt2}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterComplexFt2(XQueryParser.ComplexFt2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code ComplexFt2}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitComplexFt2(XQueryParser.ComplexFt2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code SimpleFt}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterSimpleFt(XQueryParser.SimpleFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SimpleFt}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitSimpleFt(XQueryParser.SimpleFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LogicFt}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterLogicFt(XQueryParser.LogicFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LogicFt}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitLogicFt(XQueryParser.LogicFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BktFt}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterBktFt(XQueryParser.BktFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BktFt}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitBktFt(XQueryParser.BktFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotFt}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterNotFt(XQueryParser.NotFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotFt}
	 * labeled alternative in {@link XQueryParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitNotFt(XQueryParser.NotFtContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#navigationOp}.
	 * @param ctx the parse tree
	 */
	void enterNavigationOp(XQueryParser.NavigationOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#navigationOp}.
	 * @param ctx the parse tree
	 */
	void exitNavigationOp(XQueryParser.NavigationOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#docName}.
	 * @param ctx the parse tree
	 */
	void enterDocName(XQueryParser.DocNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#docName}.
	 * @param ctx the parse tree
	 */
	void exitDocName(XQueryParser.DocNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#fileName}.
	 * @param ctx the parse tree
	 */
	void enterFileName(XQueryParser.FileNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#fileName}.
	 * @param ctx the parse tree
	 */
	void exitFileName(XQueryParser.FileNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#tagName}.
	 * @param ctx the parse tree
	 */
	void enterTagName(XQueryParser.TagNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#tagName}.
	 * @param ctx the parse tree
	 */
	void exitTagName(XQueryParser.TagNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#attName}.
	 * @param ctx the parse tree
	 */
	void enterAttName(XQueryParser.AttNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#attName}.
	 * @param ctx the parse tree
	 */
	void exitAttName(XQueryParser.AttNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#compOp}.
	 * @param ctx the parse tree
	 */
	void enterCompOp(XQueryParser.CompOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#compOp}.
	 * @param ctx the parse tree
	 */
	void exitCompOp(XQueryParser.CompOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link XQueryParser#stringCondition}.
	 * @param ctx the parse tree
	 */
	void enterStringCondition(XQueryParser.StringConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link XQueryParser#stringCondition}.
	 * @param ctx the parse tree
	 */
	void exitStringCondition(XQueryParser.StringConditionContext ctx);
}