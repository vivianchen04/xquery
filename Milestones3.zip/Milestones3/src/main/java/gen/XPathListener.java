// Generated from /Users/vivianchen/Desktop/Milestones1/src/main/java/gen/XPath.g4 by ANTLR 4.13.1
package gen;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link XPathParser}.
 */
public interface XPathListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link XPathParser#ap}.
	 * @param ctx the parse tree
	 */
	void enterAp(XPathParser.ApContext ctx);
	/**
	 * Exit a parse tree produced by {@link XPathParser#ap}.
	 * @param ctx the parse tree
	 */
	void exitAp(XPathParser.ApContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule2}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule2(XPathParser.RpRule2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule2}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule2(XPathParser.RpRule2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule3}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule3(XPathParser.RpRule3Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule3}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule3(XPathParser.RpRule3Context ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule4}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule4(XPathParser.RpRule4Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule4}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule4(XPathParser.RpRule4Context ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule5}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule5(XPathParser.RpRule5Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule5}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule5(XPathParser.RpRule5Context ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule6}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule6(XPathParser.RpRule6Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule6}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule6(XPathParser.RpRule6Context ctx);
	/**
	 * Enter a parse tree produced by the {@code OtherRp2}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterOtherRp2(XPathParser.OtherRp2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code OtherRp2}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitOtherRp2(XPathParser.OtherRp2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterFilterRp(XPathParser.FilterRpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitFilterRp(XPathParser.FilterRpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BktRp}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterBktRp(XPathParser.BktRpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BktRp}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitBktRp(XPathParser.BktRpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RpRule1}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterRpRule1(XPathParser.RpRule1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code RpRule1}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitRpRule1(XPathParser.RpRule1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code OtherRp1}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterOtherRp1(XPathParser.OtherRp1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code OtherRp1}
	 * labeled alternative in {@link XPathParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitOtherRp1(XPathParser.OtherRp1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code ComplexFt1}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterComplexFt1(XPathParser.ComplexFt1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code ComplexFt1}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitComplexFt1(XPathParser.ComplexFt1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code ComplexFt2}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterComplexFt2(XPathParser.ComplexFt2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code ComplexFt2}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitComplexFt2(XPathParser.ComplexFt2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code SimpleFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterSimpleFt(XPathParser.SimpleFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SimpleFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitSimpleFt(XPathParser.SimpleFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LogicFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterLogicFt(XPathParser.LogicFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LogicFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitLogicFt(XPathParser.LogicFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BktFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterBktFt(XPathParser.BktFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BktFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitBktFt(XPathParser.BktFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterNotFt(XPathParser.NotFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotFt}
	 * labeled alternative in {@link XPathParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitNotFt(XPathParser.NotFtContext ctx);
	/**
	 * Enter a parse tree produced by {@link XPathParser#navigationOp}.
	 * @param ctx the parse tree
	 */
	void enterNavigationOp(XPathParser.NavigationOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link XPathParser#navigationOp}.
	 * @param ctx the parse tree
	 */
	void exitNavigationOp(XPathParser.NavigationOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link XPathParser#docName}.
	 * @param ctx the parse tree
	 */
	void enterDocName(XPathParser.DocNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XPathParser#docName}.
	 * @param ctx the parse tree
	 */
	void exitDocName(XPathParser.DocNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XPathParser#fileName}.
	 * @param ctx the parse tree
	 */
	void enterFileName(XPathParser.FileNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XPathParser#fileName}.
	 * @param ctx the parse tree
	 */
	void exitFileName(XPathParser.FileNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XPathParser#tagName}.
	 * @param ctx the parse tree
	 */
	void enterTagName(XPathParser.TagNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XPathParser#tagName}.
	 * @param ctx the parse tree
	 */
	void exitTagName(XPathParser.TagNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XPathParser#attName}.
	 * @param ctx the parse tree
	 */
	void enterAttName(XPathParser.AttNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XPathParser#attName}.
	 * @param ctx the parse tree
	 */
	void exitAttName(XPathParser.AttNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XPathParser#compOp}.
	 * @param ctx the parse tree
	 */
	void enterCompOp(XPathParser.CompOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link XPathParser#compOp}.
	 * @param ctx the parse tree
	 */
	void exitCompOp(XPathParser.CompOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link XPathParser#stringCondition}.
	 * @param ctx the parse tree
	 */
	void enterStringCondition(XPathParser.StringConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link XPathParser#stringCondition}.
	 * @param ctx the parse tree
	 */
	void exitStringCondition(XPathParser.StringConditionContext ctx);
}